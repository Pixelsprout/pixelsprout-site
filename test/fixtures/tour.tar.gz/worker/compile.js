fetch(new URL("compile.wasm", import.meta.url));
